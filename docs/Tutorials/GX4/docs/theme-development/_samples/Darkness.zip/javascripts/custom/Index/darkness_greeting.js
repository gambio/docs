// This file is executed on the main page only
(function () {
  console.log(
    "Hello from the dark side!"
  );
})();
