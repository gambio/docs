// Add dark mode toggle functionality. This script is always invoked
(function () {
  const switcher = document.querySelector("#darkmode-switcher");

  switcher.addEventListener("click", () =>
    document.body.classList.toggle("darkmode")
  );

  switcher.click();
})();
