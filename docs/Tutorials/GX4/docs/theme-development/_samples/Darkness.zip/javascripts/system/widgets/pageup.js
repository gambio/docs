// We just overload the "pageup" widget with this noop module to hide the back-to-top button
gambio.widgets.module("pageup", [], function () {
  return {
    init(done) {
      done();
    },
  };
});
