<?php

$t_language_text_section_content_array = [
    'title' => 'Darkness',
    'description' => 'Das dunkle Theme mit starken Kontrasten'
];
