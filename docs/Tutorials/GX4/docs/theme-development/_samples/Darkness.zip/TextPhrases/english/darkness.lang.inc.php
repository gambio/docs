<?php

$t_language_text_section_content_array = [
    'title' => 'Darkness',
    'description' => 'The dark theme with strong contrasts'
];
