<?php

$themeSettingsArray = [
    'THEME_PRESENTATION_VERSION' => 4.0
];

$themeSettings = MainFactory::create_object('DefaultThemeSettings');
$themeSettings->setThemeSettingsArray($themeSettingsArray);
$themeSettingsArray = $themeSettings->getThemeSettingsArray();
