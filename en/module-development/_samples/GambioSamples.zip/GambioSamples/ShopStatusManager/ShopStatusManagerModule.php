<?php
/* --------------------------------------------------------------
 ShopStatusManagerModule.php 2020-09-08
 Gambio GmbH
 http://www.gambio.de
 Copyright (c) 2020 Gambio GmbH
 Released under the GNU General Public License (Version 2)
 [http://www.gnu.org/licenses/gpl-2.0.html]
 --------------------------------------------------------------
 */

declare(strict_types=1);

namespace GXModules\GambioSamples\ShopStatusManager;

use Gambio\Core\Application\Modules\AbstractModule;
use GXModules\GambioSamples\TwigAdminEngine\Support\TwigAction;

// Note: To see this module in action, you can use the admin menu group "Layout & Design" and use
// the item "Shop Status" which is above of the shop-offline item.

/**
 * Class ShopStatusManagerModule
 *
 * @package GXModules\GambioSamples\ShopStatusManager
 */
class ShopStatusManagerModule extends AbstractModule
{
    /**
     * @inheritDoc
     */
    public function dependsOn(): ?array
    {
        return [
            TwigAction::class
        ];
    }
}