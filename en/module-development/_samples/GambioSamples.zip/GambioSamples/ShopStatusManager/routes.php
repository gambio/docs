<?php
/* --------------------------------------------------------------
 routes.php 2021-05-14
 Gambio GmbH
 http://www.gambio.de
 Copyright (c) 2021 Gambio GmbH
 Released under the GNU General Public License (Version 2)
 [http://www.gnu.org/licenses/gpl-2.0.html]
 --------------------------------------------------------------
 */

declare(strict_types=1);

use Gambio\Core\Application\Routing\RouteCollector;
use GXModules\GambioSamples\ShopStatusManager\App\Actions\SaveOfflineStatus;
use GXModules\GambioSamples\ShopStatusManager\App\Actions\SavePopup;
use GXModules\GambioSamples\ShopStatusManager\App\Actions\SaveTopbar;
use GXModules\GambioSamples\ShopStatusManager\App\Actions\ShopStatusOverview;

return static function (RouteCollector $routeCollector) {
    $routeCollector->get('/admin/gambio-samples/shop-status', ShopStatusOverview::class);
    
    $routeCollector->post('/admin/gambio-samples/shop-status/top-bar', SaveTopbar::class);
    $routeCollector->post('/admin/gambio-samples/shop-status/popup', SavePopup::class);
    $routeCollector->post('/admin/gambio-samples/shop-status/shop-status', SaveOfflineStatus::class);
};
